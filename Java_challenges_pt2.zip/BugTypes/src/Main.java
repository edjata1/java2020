public class Main {

    //understanding extends with a super class and subclasses
    //in this case Insect is the super class and spider & cricket are the subclasses
    public static void main(String[] args){

        //Super class Insect
        Insect insect = new Insect(5, 6);

        //Spider & Cricket extends super class of Insect
        Spider spider = new Spider(13, true);
        Cricket cricket = new Cricket(2, 1.25);

        System.out.println("insect: ");
        insect.crawl();
        insect.says();

        System.out.println("spider: ");
        spider.crawl();
        spider.says();

        System.out.println("cricket: ");
        cricket.crawl();
        cricket.says();
        cricket.jump();
        System.out.println(cricket.length);

        if(spider instanceof Insect && spider instanceof Spider){
            System.out.println("Spider is an insect and a spider");
        }
    }
}
