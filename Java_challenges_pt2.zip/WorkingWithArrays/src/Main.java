import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {

    public static void main(String[] args){

        //array call hold different value but all of same data type
        System.out.println("Array # list: 31, 45, 22, 98, 10");
        //set size of array
        int[] numbers = new int[5];
        numbers[0] = 31;
        numbers[1] = 45;
        numbers[2] = 22;
        numbers[3] = 98;
        numbers[4] = 10;
        Arrays.sort(numbers);
        System.out.println(Arrays.toString(numbers));


        int num007[] ={31, 45, 22, 98, 10};
        for (int i = 0; i < num007.length; i++) {
            System.out.print("At index " + i);
            System.out.print(" is: "+num007[i]);
            System.out.print(", ");
        }

        String[] myFavoriteCandyBars ={"Twix", "Hershey's", "Crunch"};
        System.out.println("\nIndex 1 " + myFavoriteCandyBars[1]);
        myFavoriteCandyBars[2] = "Butterfingers";
        System.out.println(myFavoriteCandyBars[2]);
        System.out.println("Length: " + myFavoriteCandyBars.length);

        System.out.println(Array.get(myFavoriteCandyBars, 2));
    }
}
