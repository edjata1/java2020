
public class Person2Main {
	
	public static void main(String[] args){
		
		Person p = new Person();
		p.firstName = "Empress";
		p.lastName = "Djata";
		p.printName();
	}

}
