import java.awt.*;

public class Car {

    int averageMilePerGallon;
    String licensePlate;
    Color paintColor;
    boolean areTailLightsWorking;

    public Car(int inputAverageMPG,
               String inputLicensePlate,
               Color inputPaintColor,
               boolean inputAreTailLightsWorking){

        this.averageMilePerGallon = inputAverageMPG;
        this.licensePlate = inputLicensePlate;
        this.paintColor = inputPaintColor;
        this.areTailLightsWorking = inputAreTailLightsWorking;

    }

    public void changePaintColor (Color newPaintColor){

        this.paintColor = newPaintColor;
    }
}
