import java.awt.*;
import java.lang.reflect.Array;
import java.util.Scanner;

public class Main {

    public static void main(String [] args){
//        System.out.println("Hello World");
//        System.out.println("Empress");
//
//        Car car1 = new Car(25,
//                "EDJ5479",
//                Color.RED,
//                true);
//
//        Car car2 = new Car(35,
//                "SEXY69",
//                Color.BLUE,
//                false);
//
//        System.out.println("Car 1: " + car1.licensePlate);
//        System.out.println("Car 2: " + car2.licensePlate);
//
//        System.out.println("Car 1 old color: " + car1.paintColor.toString());
//        car1.changePaintColor(Color.BLACK);
//        System.out.println("Car 1 new paint color: " + car1.paintColor.toString());

//        System.out.print("Enter a word: ");
        /*System.out.print("Enter a integer and a double: ");
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        System.out.println(num);
        double num2 = sc.nextDouble();
        System.out.println(num2);*/

/*        String userInput = sc.next();

        String upperCase = userInput.toUpperCase();
        System.out.println(userInput);
        System.out.println(upperCase);

        char firstCharacter = userInput.charAt(0);
        System.out.println(firstCharacter);

        System.out.println("Contains: " + userInput.contains("Enter".toLowerCase()));*/

        int num[] ={31, 45, 22, 98, 10};
        for (int i = 0; i < num.length; i++) {
            System.out.print(num[i]);
            System.out.print(", ");
        }
        System.out.println(num[0]);


    }
}
