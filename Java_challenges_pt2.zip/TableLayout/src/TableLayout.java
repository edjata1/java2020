import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.AbstractTableModel;

import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;

public class TableLayout {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application with main method.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TableLayout window = new TableLayout();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//data source
	//class TableData extends AbstractTableModel{

		/*
		//new instance variable
		//1. create array of array's new property [Row][Column]
		String [][] allData = new String[3][3];
		
		//2.create constructor
		public TableData(){
			allData[0][0] = "1";
			allData[0][1] = "2";
			allData[0][2] = "3";
			allData[1][0] = "4";
			allData[1][1] = "5";
			allData[1][2] = "6";
			allData[2][0] = "7";
			allData[2][1] = "8";
			allData[2][2] = "9";
		}
		
		*/
		
		//getting data from data source txt file
		class TableData extends AbstractTableModel{
			int [][] allData;
			
			public TableData(){
				try{
					loadFile();
				}
				catch(IOException e){
					System.out.println(e);
				}
			}
		
			//load file
			void loadFile() throws IOException {
				//FileReader file = new FileReader("data.txt");
				//use InputStream & InputStreamReader when bundling files & files need to be in class level of file
				InputStream stream = getClass().getClassLoader().getResourceAsStream("data.txt");
				InputStreamReader sReader = new InputStreamReader(stream);
				BufferedReader reader = new BufferedReader(sReader);
				
				String line;
				int r = 0;
				while ((line = reader.readLine()) != null){
					String[] aLine = line.split("\\s+");
					if(allData == null){
						allData = new int[aLine.length][aLine.length];
					}
					for(int c = 0; c < aLine.length; c++){
						int iData = Integer.parseInt(aLine[c]);
						allData[r][c] = iData;
					}
					r++;
					
				}
				stream.close();
				sReader.close();
				reader.close();
			}
			
			@Override
			public int getRowCount() {
				// TODO Auto-generated method stub
				return allData.length;
			}
			
			@Override
			public int getColumnCount() {
				// TODO Auto-generated method stub
				return allData[0].length;
			}
	
			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				return allData[rowIndex][columnIndex];
			}
		
		}
		
	//}

	/**
	 * Create the application.
	 */
	public TableLayout() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 381, 73);
		frame.getContentPane().add(scrollPane);
		
		//table is created
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setBorder(new BevelBorder(BevelBorder.RAISED, Color.GRAY, null, null, null));

		
		//instance of TableData
		TableData data = new TableData();
		//connect to table
		table.setModel(data);
		
	}
}
