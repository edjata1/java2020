import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        //replace letters in String
        String s = "dog";
        String replacedF = s.replace("d","f");
        System.out.println(s + " is now " + replacedF);

        //Working with Strings
        String userInput1 = "entertainment";
        String upperCased = userInput1.toUpperCase();
        System.out.println(upperCased);
        char firstChar = userInput1.charAt(0);
        //userInput1 not modified
        System.out.println(firstChar);
        //true or false
        System.out.println("Contains: " + userInput1.contains("Enter"));
        System.out.println("Contains: " + userInput1.contains("Enter".toLowerCase()));

        //Working with user input using Scanner call
        System.out.println();

        System.out.print("Enter a integer and a double: ");
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        System.out.println(num);
        double num2 = sc.nextDouble();
        System.out.println(num2);

        System.out.println("Enter a word: ");
        String userInput = sc.next();

        String upperCase = userInput.toUpperCase();
        System.out.println(userInput);
        System.out.println(upperCase);

        char firstCharacter = userInput.charAt(0);
        System.out.println(firstCharacter);

        System.out.println("Contains: " + userInput.contains("Enter".toLowerCase()));

    }
}
