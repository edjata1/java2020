import java.awt.*;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

//body shop where we create Cars
public class Main {

    public static void main(String[] args){

        //Car instances:
        //data type variable name = new keyword call constructor(input values)
        Car car1 = new Car(25,
        "EDJ5479",
        Color.RED,
        true);

        Car car2 = new Car(35,
                "SEXY69",
                Color.BLUE,
                false);

        //output (String + object.property)
        //variable or object. access methods or properties
        System.out.println("Car 1: " + car1.licensePlate);
        System.out.println("Car 2: " + car2.licensePlate);

        //print before and after of method
        System.out.println("Car 1 old color: " + car1.paintColor.toString());
        //object calling function or method (new color entered here)
        car1.changePaintColor(Color.BLACK);
        System.out.println("Car 1 new paint color: " + car1.paintColor.toString());

        //using speedingUp method
        double myCarSpeed = 50;
        myCarSpeed = car1.speedingUp(myCarSpeed);
        System.out.println("Speed: " + myCarSpeed);

    }
}
