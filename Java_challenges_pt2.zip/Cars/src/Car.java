//import libraries:
import java.awt.*;

//Car class is blueprint:
public class Car {

    // Some Data types: int, double, String, Color, boolean,
        int averageMilePerGallon;
        String licensePlate;
        Color paintColor;
        boolean areTailLightsWorking;

    //constructor method for building car by passing data
    //Car() is name of function, initializing Car with input values using this
        public Car(int inputAverageMPG,
                   String inputLicensePlate,
                   Color inputPaintColor,
                   boolean inputAreTailLightsWorking){

            this.averageMilePerGallon = inputAverageMPG;
            this.licensePlate = inputLicensePlate;
            this.paintColor = inputPaintColor;
            this.areTailLightsWorking = inputAreTailLightsWorking;

        }

    //methods or functions
    // interact with Car
    //1st. line signature of method, basic components of method
        public void changePaintColor (Color newPaintColor){

            //change paint color
            //this = object name i.e. car1
            this.paintColor = newPaintColor;
        }

    //speedingUp method
        public double speedingUp(double currentSpeed){

            currentSpeed += 100;

            return currentSpeed;
        }
}
