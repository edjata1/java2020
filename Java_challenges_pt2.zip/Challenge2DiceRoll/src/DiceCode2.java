import java.util.Random;

public class DiceCode2 {

    Random rand;
    int previousRoll = -1;

    public DiceCode2(){
        this.rand = new Random();
    }


    public int roll(){

        int currentRoll = this.rand.nextInt(6) + 1;
        this.previousRoll = currentRoll;
        return currentRoll;
    }
}
