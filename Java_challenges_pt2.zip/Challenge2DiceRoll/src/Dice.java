import java.util.Random;

public class Dice {

    int dice;


    public Dice(){

    }

    public int roll(){

        Random rand = new Random();
        dice = rand.nextInt(6);

        return dice +1;
    }



}
