import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        String userInput;
        System.out.print("Type Roll: ");
        Scanner sc = new Scanner(System.in);
        userInput = sc.next();

        if (userInput.equalsIgnoreCase("roll")){
            Dice dice1 = new Dice();
            Dice dice2 = new Dice();

            int d1 = dice1.roll();
            int d2 = dice2.roll();
            System.out.println("Dice 1: [" + d1 +"], " + "Dice 2: [" + d2+"]");
        }else{
            System.out.println("Thanks for playing!");
        }


        DiceCode2 myDice = new DiceCode2();

        System.out.println(myDice.previousRoll);

        System.out.println("D1: "+myDice.roll());
        System.out.println(myDice.previousRoll);

        System.out.println("D2: "+myDice.roll());
        System.out.println(myDice.previousRoll);


    }
}
