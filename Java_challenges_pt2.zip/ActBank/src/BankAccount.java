public class BankAccount {

    private int account_number;
    private int account_balance;

    public BankAccount(int account_number, int account_balance){
        this.account_number = account_number;
        this.account_balance = account_balance;
        System.out.println("You created account "
                + this.account_number + ".");
    }

    public void createNewAccount(int newAccount_number,
                                 int openingDeposit){

        this.account_number = newAccount_number;
        deposit(openingDeposit);

    }

    public void deposit(int addMoney) {
        if (addMoney < 0) {
            System.out.println("You cannot deposit a "
                    + "negative amount");
        }else {
            this.account_balance = this.account_balance + addMoney;
            System.out.println("$"+ addMoney +" was "
                    + "deposited into your account "+ this.account_number
                    +" and the balance is $" + this.account_balance  +".");
        }

    }

    public void withdraw(int removeMoney) {
        if (removeMoney > this.account_balance) {
            System.out.println("You cannot withdraw more "
                    + "than what's in your account");
        }else {
            this.account_balance = this.account_balance - removeMoney;
            System.out.println("$"+ removeMoney +" "
                    + "was withdrawn from account "+ this.account_number
                    + ". Your account balance is now $"
                    + this.account_balance);
        }
    }
}
