public class ResourceManager {

    /**
     * @parm args the command line arguments
     */

    public static void main(String[] args){

        PrintSpooler spooler = PrintSpooler.getInstance();

        //first thread
        Thread threadOne = new Thread(() ->
        {PrintSpooler s = PrintSpooler.getInstance();});

        //Second thread
        Thread threadTwo = new Thread(() ->
        {PrintSpooler s = PrintSpooler.getInstance();});

        threadOne.start();
        threadTwo.start();

    }
}
