

public class Person {
	public String firstName = "(NOT SET)";
	public String lastName = "(NOT SET)";
	
	public void printName(){
		System.out.println(firstName + " " + lastName);
	}
}
