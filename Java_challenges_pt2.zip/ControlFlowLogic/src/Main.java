import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        System.out.println("Please enter your name: ");
        Scanner sc = new Scanner(System.in);

        String name = sc.next();

        System.out.print("Enter your age: ");
        Scanner sc1 = new Scanner(System.in);

        int age = sc1.nextInt();

        if (age >= 0 && age <= 5){
            System.out.println(name + " is a Baby");
        }else if (age >= 6 && age <= 11){
            System.out.println(name + " is a Kid");
        }else if (age >= 12 && age <= 17){
            System.out.println(name + " is a Teen");
        }else if(age >= 18){
            System.out.println(name + " is a Adult");
        }else {
            System.out.println("Come, come now "+name+", you know that's invalid");
        }

        System.out.println("Thanks for using this program " + name +"!");
    }
}
