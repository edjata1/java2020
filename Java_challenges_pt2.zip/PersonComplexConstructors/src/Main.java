import java.awt.*;
import java.time.LocalDate;

public class Main {

    public static void main(String [] args){

        Person person = new Person("John", 31,
                Color.BLACK, Color.blue, "Teacher",
                "Canadian",
                LocalDate.of(1991, 8, 10), "Ottawa");


    }
}
