import java.awt.*;
import java.time.LocalDate;

public class Person {

    String name;
    int age;
    Color Hair, Eyes;
    String occupation, nationality, city;
    LocalDate dob;


    public Person(String name,
                  int age,
                  Color Hair,
                  Color Eyes,
                  String occupation,
                  String nationality,
                  LocalDate dob,
                  String city){

        this.name = name;
        this.age = age;
        this.Hair = Hair;
        this.Eyes = Eyes;
        this.occupation = occupation;
        this.nationality = nationality;
        this.dob = dob;
        this.city = city;

    }
}
