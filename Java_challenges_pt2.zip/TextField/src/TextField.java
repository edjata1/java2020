import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class TextField {

	private JFrame frame;
	private JTextField txtEnterName;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JLabel lblZip;
	private JTextField textField_3;
	private JLabel lblUserName;
	private JTextField textField_4;
	private JLabel lblNewLabel;
	private JTextField textField_5;
	private JLabel lblNewLabel_1;
	private JTextField textField_6;
	private JButton btnLogin;
	private JButton btnRegister;
	private JLabel lblForgotLogin;
	private JLabel lblForgotPassword;
	private JLabel regCompletedLabel;
	
	private JRadioButton item2;
	private JRadioButton item3;
	private JRadioButton item4;
	
	private final ButtonGroup radios = new ButtonGroup();
	
	static JLabel groupLabel = new JLabel("Artist");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TextField window = new TextField();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	class RadioListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			//  e parameter =  event that happened when clicked
			JRadioButton btn = (JRadioButton)e.getSource();
			//update label
			groupLabel.setText(btn.getText());
		}	
	}	
	

	/**
	 * Create the application.
	 */
	public TextField() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name: ");
		lblName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblName.setForeground(new Color(255, 20, 147));
		lblName.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblName.setBounds(33, 18, 46, 14);
		frame.getContentPane().add(lblName);
		
		txtEnterName = new JTextField();
		txtEnterName.setToolTipText("");
		txtEnterName.setFont(new Font("Times New Roman", Font.BOLD, 13));
		txtEnterName.setBounds(88, 11, 178, 20);
		frame.getContentPane().add(txtEnterName);
		txtEnterName.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address: ");
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblAddress.setForeground(new Color(255, 20, 147));
		lblAddress.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAddress.setBounds(20, 43, 59, 14);
		frame.getContentPane().add(lblAddress);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.BOLD, 13));
		textField.setToolTipText("Enter Address");
		textField.setBounds(88, 37, 178, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblCity = new JLabel("City:");
		lblCity.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblCity.setForeground(new Color(255, 20, 147));
		lblCity.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCity.setBounds(33, 68, 43, 14);
		frame.getContentPane().add(lblCity);
		
		textField_1 = new JTextField();
		textField_1.setBounds(88, 63, 108, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblState = new JLabel("State:");
		lblState.setForeground(new Color(255, 20, 147));
		lblState.setHorizontalAlignment(SwingConstants.RIGHT);
		lblState.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblState.setBounds(30, 93, 46, 14);
		frame.getContentPane().add(lblState);
		
		textField_2 = new JTextField();
		textField_2.setBounds(88, 87, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		lblZip = new JLabel("Zip:");
		lblZip.setForeground(new Color(255, 20, 147));
		lblZip.setHorizontalAlignment(SwingConstants.RIGHT);
		lblZip.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblZip.setBounds(30, 118, 46, 14);
		frame.getContentPane().add(lblZip);
		
		textField_3 = new JTextField();
		textField_3.setBounds(88, 112, 86, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		lblUserName = new JLabel("User Name:");
		lblUserName.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblUserName.setForeground(new Color(255, 20, 147));
		lblUserName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUserName.setBounds(10, 136, 69, 14);
		frame.getContentPane().add(lblUserName);
		
		textField_4 = new JTextField();
		textField_4.setBounds(88, 137, 86, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		lblNewLabel = new JLabel("Password:");
		lblNewLabel.setForeground(new Color(255, 20, 147));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(10, 161, 69, 14);
		frame.getContentPane().add(lblNewLabel);
		
		textField_5 = new JTextField();
		textField_5.setBounds(88, 162, 86, 20);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setForeground(new Color(255, 20, 147));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(10, 186, 66, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField_6 = new JTextField();
		textField_6.setBounds(88, 186, 86, 20);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		btnLogin = new JButton("LogIn");
		btnLogin.setBounds(113, 211, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//get text in component
				String name = txtEnterName.getText();
				regCompletedLabel.setText("Registration Completed " + name + "!");
				
			}
		});
		btnRegister.setBounds(212, 211, 89, 23);
		frame.getContentPane().add(btnRegister);
		
		lblForgotLogin = new JLabel("Forgot LogIn");
		lblForgotLogin.setFont(new Font("Times New Roman", Font.BOLD, 11));
		lblForgotLogin.setForeground(new Color(255, 20, 147));
		lblForgotLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblForgotLogin.setBounds(104, 236, 101, 14);
		frame.getContentPane().add(lblForgotLogin);
		
		lblForgotPassword = new JLabel("Forgot Password");
		lblForgotPassword.setFont(new Font("Times New Roman", Font.BOLD, 11));
		lblForgotPassword.setForeground(new Color(255, 20, 147));
		lblForgotPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblForgotPassword.setBounds(204, 236, 108, 14);
		frame.getContentPane().add(lblForgotPassword);
		
		regCompletedLabel = new JLabel("");
		regCompletedLabel.setBounds(179, 186, 250, 14);
		frame.getContentPane().add(regCompletedLabel);
		
		JLabel newsletterReg = new JLabel("Don't Send");
		newsletterReg.setBounds(276, 29, 148, 14);
		frame.getContentPane().add(newsletterReg);
		
		JCheckBox newsletterChecksBox = new JCheckBox("Get Newsletter");
		newsletterChecksBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = (newsletterChecksBox.isSelected())? "Send me Newsletters" : "Don't Send";
				newsletterReg.setText(text);
			}
		});
		newsletterChecksBox.setBounds(319, 7, 97, 23);
		frame.getContentPane().add(newsletterChecksBox);
		
		JRadioButton item1 = new JRadioButton("Artist");
		radios.add(item1);
		item1.setSelected(true);
		item1.setBounds(202, 62, 81, 23);
		frame.getContentPane().add(item1);
		
		item2 = new JRadioButton("A&R Rep");
		radios.add(item2);
		item2.setBounds(202, 87, 99, 23);
		frame.getContentPane().add(item2);
		
		item3 = new JRadioButton("Manager");
		radios.add(item3);
		item3.setBounds(202, 112, 110, 23);
		frame.getContentPane().add(item3);
		
		item4 = new JRadioButton("Fan");
		radios.add(item4);
		item4.setBounds(203, 134, 81, 23);
		frame.getContentPane().add(item4);
		
//		groupLabel = new JLabel("Artist");
		groupLabel.setHorizontalAlignment(SwingConstants.LEFT);
		groupLabel.setBounds(209, 161, 81, 14);
		frame.getContentPane().add(groupLabel);
		
		//listener for radio button
		RadioListener listener = new RadioListener();
		item1.addActionListener(listener);
		item2.addActionListener(listener);
		item3.addActionListener(listener);
		item4.addActionListener(listener);

	}
}
