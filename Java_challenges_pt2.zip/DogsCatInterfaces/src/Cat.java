public class Cat implements Pet {
    public void play(){
        System.out.println("The cat plays with its owner.");
    }
}
