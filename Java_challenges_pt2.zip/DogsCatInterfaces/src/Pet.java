//Interfaces are the definition  of behavior
//when used, they focus classes and objects to have certain properties without
//forcing their implementation

public interface Pet {
    void play();
}
