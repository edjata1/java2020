public class Main {
    public static void main(String[] args){

        Answerable phone = () -> {return "Hello";};
        //or
        Answerable phone1 = () -> " Empress";

        System.out.println(phone.answer() + phone1.answer());

        //n % by 2 see if odd or even, odd = 0, even = 1
        Predicate isOdd = n -> n % 2 != 0;
        System.out.println(isOdd.test(2));

        Predicate isEven = n -> n % 2 == 0;
        System.out.println(isEven.test(2));


    }
}
