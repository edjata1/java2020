import java.util.Random;

public class Main {

    public static void main (String[] args){

        //Math class
        double power = Math.pow(5, 3);
        System.out.println("Math Library Power 5*5*5: " + power);

        double squareRoot = Math.sqrt(64);
        System.out.println("SquareRoot 64: " + squareRoot);

        //Random call, rand object
        Random rand = new Random();
        //randomNumber variable
        int randomNumber = rand.nextInt();
        int randomNumberWithBound = rand.nextInt(10);
        System.out.println("Random Number: " + randomNumber);
        System.out.println("Random Number With Bounds: "
                + randomNumberWithBound);


    }
}
