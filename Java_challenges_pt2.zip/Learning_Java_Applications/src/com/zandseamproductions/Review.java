package com.zandseamproductions;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/*
 * This is Learning Java Applications with Todd
 */

public class Review {

	public static void main(String[] args) {
		
		//--------------------------------
		System.out.println("String review: ");
		
		String myName = "Empress";
		float favoriteNumber = 5;
		System.out.println("Hi, my name is " + myName 
				+ " and my favorite number is " +
				favoriteNumber);
		
		//--------------------------------
		System.out.println("Method Review inside main: ");
		
		//called using Review class = run on class
		//calling inside main class because method is static can call Method like this
		Review.exampleStatic();
		
		//called using instance = run on instance
		//calling inside main class because method isn't static can call Method like this
		Review myReview = new Review();
		myReview.exampleMethod();
		
		//example parameter method
		Review myParameterMethod = new Review();
		myParameterMethod.parameterMethod("3. Parameter Method");
		
		//return value
		Review myReturnValue = new Review();
		myReturnValue.returnValue("4. Return value Method");
		
		//--------------------------------
		System.out.println("Array Review: ");
		
		String[] breakfast = new String[3];
		breakfast[0] = "Pancakes";
		breakfast[1] = "Eggs";
		breakfast[2] = "beef saucage";
		
		System.out.println("Breakfast Array food: ");
		
		for(int i = 0; i < breakfast.length; i++){
			int x = i + 1;	
			System.out.println(x + ". " +breakfast[i]);
		}
		
		//--------------------------------
		System.out.println("Conditional Statements:");
		
		//True or false evaluations
		//is equal to ==
		//Setting a value =
		//OR = ||, AND &&
		if(1 == 0 && 1 == 1){
			System.out.println("Statement is true");
		}
		else if(0 == 0){
			System.out.println("Statement is false, else if statement is true");
		}
		else{
			System.out.println("Statement is false 3");
		}
		
		//--------------------------------
		System.out.println("Review java classes -> muClass");

		//new Instance of myClass
		MyClass mc = new MyClass();
		MyClass myClass = new MyClass(6);
		myClass.myMethod();
		//property myNum use class instance
		System.out.println(mc.myNum);
		
		//--------------------------------
		System.out.println("Review Read input: Scanner Class");

		System.out.println("What is your first name? ");
		Scanner sc = new Scanner(System.in);
		
		String userInput = sc.next();
		System.out.println("Hello " + userInput +" let's play. ");
		
		System.out.println("Enter first number: ");
		int num1 = sc.nextInt();
		System.out.println("Enter Second number: ");
		int num2 = sc.nextInt();
		System.out.println(num1 + " + " + num2 + " sum: " +(num1 + num2));
		
		//--------------------------------
		System.out.println("Review loading data from text file using buffered reader: ");
		try {
			//reading from a file: 
			//Create file Reader instance
			FileReader file = new FileReader("hello");
			//create buffered reader instance
			BufferedReader reader = new BufferedReader(file);
			//using while loop and String variable grab data & use it
			String data;
			while((data = reader.readLine())!= null){
				System.out.println(data);
			}
			//close out reader
			reader.close();
		} catch (IOException error) {
			// TODO Auto-generated catch block
			System.out.println(error);
		}

		
		//--------------------------------
		System.out.println("Review ");		
		
		
		
	}
	
	//Different type of functions or methods:
	
	//function that returns a value
	public String returnValue(String returnValueMessage){
		System.out.println(returnValueMessage);
		return returnValueMessage;
	}
	
	//parameter method send some data to method
	public void parameterMethod(String message){
		
		System.out.println(message);
		
	}
	
	//non-static function or method
	public void exampleMethod(){
		System.out.println("2. example non-static Method") ;
	}
	
	//static modifier
	//call static function or method
	public static void exampleStatic(){
		System.out.println("1. example Static Method");
	}

}
