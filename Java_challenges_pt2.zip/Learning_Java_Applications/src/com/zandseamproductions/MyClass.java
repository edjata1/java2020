package com.zandseamproductions;

public class MyClass {
	
	public int myNum = 1;
	
	
	public MyClass(){
		
		System.out.println("Constructor!! ");
	}
	
	public MyClass(int myNumber){
		this.myNum = myNumber;
		System.out.println("Constructor with number: " + myNumber);
	}

	public void myMethod(){
		System.out.println("Just a  Method");
	}
}
