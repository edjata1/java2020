import java.util.Scanner;

public class Main {

    public static void main(String[] args){

//        System.out.print("Please make your call Heads or Tails? ");
//        Scanner userChoice = new Scanner(System.in);

        Coin c = new Coin();
        System.out.println("Initial: " + c.getFaceUp());

        for (int i = 0; i < 10; i++) {
            c.flip();
            System.out.println("After flip: " + c.getFaceUp());
        }


    }
}
