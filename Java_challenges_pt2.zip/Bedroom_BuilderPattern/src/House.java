import java.util.ArrayList;

public class House {

    private ArrayList listOfRooms;

    public House(ArrayList listOfRooms){
        this.listOfRooms = listOfRooms;
    }
}
