public class Main {

    public static void main(String[] args){

        Train myFirstBxTrain = new Train(150.5,
                "Flatbush, BK",
                true,
                9);

        System.out.println(myFirstBxTrain.destination);

        System.out.println(myFirstBxTrain.changeDestination("Flushings, Queens"));

        myFirstBxTrain.displayOnTrain();

        double myTrainSpeed = 250;
        myTrainSpeed = myFirstBxTrain.decreaseSpeed(myTrainSpeed);
        System.out.println(myTrainSpeed);
    }
}
