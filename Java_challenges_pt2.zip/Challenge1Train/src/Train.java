public class Train {

    double speed;
    String destination;
    boolean trainInService;
    int trainNumber;

    public Train(double inputSpeed,
                 String inputDestination,
                 boolean inputTrainInService, int inputTrainNumber){

        this.speed = inputSpeed;
        this.destination = inputDestination;
        this.trainInService = inputTrainInService;
        this.trainNumber = inputTrainNumber;

    }

    public String changeDestination (String newDestination){

        this.destination = newDestination;

        return newDestination;
    }

    public void displayOnTrain(){

        System.out.println(trainNumber + " Train to "+ destination);

    }

    public double decreaseSpeed(double decreaseTheSpeed){


        decreaseTheSpeed -= 50.5;

        return decreaseTheSpeed;
    }

}
