public class Main {

    public static void main(String[] args){

        Dog myDog = new Dog("Tim", 5);
        Dog myDog2 = new Dog("Shug", 7);

        myDog.fetch();
        myDog.fetch();
        myDog.fetch();
        myDog2.fetch();

        myDog2.bark();

        int dogYears = myDog2.getDogYears();
        System.out.println(myDog2.name + " is " + dogYears +" dog years old.");

    }
}
