public class MiniDuckSimulator {

    public static void main(String[] args){

        MallardDuck mallard = new MallardDuck();
        RubberDuck rubberDuckie = new RubberDuck();
        DecoyDuck decoyDuck = new DecoyDuck();
        ModelDuck model = new ModelDuck();
        RedheadDuck redDuck = new RedheadDuck();

        mallard.performQuark();
        rubberDuckie.performQuark();
        decoyDuck.performQuark();

        model.performFly();
        model.setFlyBehavior(new FlyRocketPowered());
        model.performFly();

        mallard.swim();
        mallard.setQuackBehavior(new MuteQuack());
        mallard.performQuark();

        redDuck.performFly();
        redDuck.flyBehavior.fly();




    }
}
