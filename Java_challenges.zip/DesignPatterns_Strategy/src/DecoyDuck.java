public class DecoyDuck extends Duck{

    public DecoyDuck(){

        //what I had:
        //flyBehavior = new FlyNoWay();
        setFlyBehavior(new FlyNoWay());
        setQuackBehavior(new MuteQuack());
    }

    public void display(){

        System.out.println("I'm a Duck Decoy!");

    }
}
