import java.awt.*;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){
//        System.out.println("Hello World");
//        System.out.println("Empress");
//


        //NOTES:
        //Argument: Actual value passed to the function
        //ex: (Red is the argument)
        //changePaintColor("Red");

        //Parameter: input variable & a method definition
        //ex:(color is the Parameter
        //public static void
        //changePaintColor(String color)
        //{...}

        //Method:
        //When a method is called,
        //the parameter(s) gets the value of the argument(s)
        //that were passed to the function.

//END NOTES:

        //** JAVA IS CALL BY VALUE ONLY

        //Call by value: passing argument into a function call
        //When a function receives a copy of the argument passed to it


        //instance 1 from Car class
        //new Constructor(parameter, argument)
        Car myCar = new Car(34.5,
                "KRB456",
                Color.BLACK,
                true);

        //Call by Reference: passing argument into a function call
        //When a function receives a reference to each argument, and can modify them

        //instance 2 from Car Class
        Car sallyCar = new Car(55.5,
                "HOT6969",
                Color.RED,
                false);

        //call by value:
        double myCarSpeed = 50;
        myCar.speedingUp(myCarSpeed);
        System.out.println(myCarSpeed);

        //call by reference
        double myCarSpeed2 = 50;
            //myCarSpeed2 increase by 100 & save output of speedingUp method to myCarSpeed2
        myCarSpeed2 = myCar.speedingUp2(myCarSpeed2);
        System.out.println(myCarSpeed2);

        System.out.println(myCar.averageMilesPerGallon);

        System.out.println("Car 1: " + myCar.paintColor.toString() + " " + myCar.licensePlate );
        System.out.println("Car 2: " + sallyCar.paintColor + " " + sallyCar.licensePlate );

        myCar.changePaintColor(Color.RED);
        System.out.println("Car 1: " + myCar.paintColor.toString() + " " + myCar.licensePlate );

//
//        //Working with Strings
//        String userInput = "entertainment";
//        String upperCased = userInput.toUpperCase();
//        System.out.println(userInput);
//        System.out.println(upperCased);
//
//        char firstCharacter = userInput.charAt(0);
//        System.out.println(firstCharacter);
//
//        System.out.println("Contains: " + userInput.contains("enter"));
//
//        System.out.println("Contains: " + userInput.contains("Enter".toLowerCase()));
//
//        //Working with user input
//        System.out.print("Enter a Word: ");
//        Scanner sc = new Scanner(System.in);
//        String userInput2 = sc.next();
//
//        String upperCased2 = userInput2.toUpperCase();
//        System.out.println(userInput2);
//        System.out.println(upperCased2);
//
//        char firstCharacter2 = userInput2.charAt(0);
//        System.out.println(firstCharacter2);
//
//        System.out.println("Contains: " + userInput2.contains("enter"));
//
//        System.out.println("Contains: " + userInput2.contains("Enter".toLowerCase()));
//
//
//        //Working with numbers
//        System.out.print("Enter a number:");
//        Scanner sc2 = new Scanner(System.in);
//
//        int userNumber = sc.nextInt();
//        System.out.println(userNumber);
//
//        System.out.print("Enter a double: ");
//
//        double userNumber2 = sc2.nextDouble();
//        System.out.println(userNumber2);
//
//
//        Working with arrays
//
//        31, 45, 22, 98, 10
//        int[] numbers1 = new int[5];
//
//        numbers1[0] = 31;
//        numbers1[1] = 45;
//        numbers1[2] = 22;
//        numbers1[3] = 98;
//        numbers1[4] = 10;
//
//        Arrays.sort(numbers1);
//
//        System.out.println("Sorted:");
//        System.out.println(Arrays.toString(numbers1));
//        System.out.println(numbers1[0]);
//        System.out.println(numbers1[1]);
//        System.out.println(numbers1[2]);
//        System.out.println(numbers1[3]);
//        System.out.println(numbers1[4]);
//        System.out.println("______________________________");
//
//        //or
//        int[] numbers2 = {31, 45, 22, 98, 10};
//
//        System.out.println("Unsorted:");
//        System.out.println(numbers2[0]);
//        System.out.println(numbers2[1]);
//        System.out.println(numbers2[2]);
//        System.out.println(numbers2[3]);
//        System.out.println(numbers2[4]);
//
//        String[] myFavoriteCandyBar = {"Twix", "Hershey's", "Crunch"};
//        System.out.println("Index 1: " + myFavoriteCandyBar[1]);
//        System.out.println("Index 2: " + myFavoriteCandyBar[2]);
//        myFavoriteCandyBar[2] = "Butterfinger";
//        System.out.println("Index 2: " + myFavoriteCandyBar[2]);
//        System.out.println("Length: " + myFavoriteCandyBar.length);
//
//        System.out.println(Array.get(myFavoriteCandyBar, 2));

        //replacing letters
        String s = "dog";
        System.out.println(s);
        String replacedF = s.replace('d', 'f');
        System.out.println(replacedF);

    }
}
