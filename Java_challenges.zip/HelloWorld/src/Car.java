import java.awt.*;

//Car class blueprint

public class Car {

    //Data types:
    //int -> 1,2,3
    //double -> decimal 34.5, 32.1
    //String -> "a1a2" or "Hello World"
    //Color -> from awtt library
    //boolean -> true or false

    double averageMilesPerGallon;
    String licensePlate;
    Color paintColor;
    boolean areTailingWorking;

    //input to constructor make car
    //Car constructor method/function for Car class
    public Car(double inputAverageMPG,
               String inputLicensePlate,
               Color inputPaintColor,
               boolean inputAreTailingWorking){

        //Out is newly created Car
        //data coming from this variable from user to constructor variable
        this.averageMilesPerGallon = inputAverageMPG;
        this.licensePlate = inputLicensePlate;
        this.paintColor = inputPaintColor;
        this.areTailingWorking = inputAreTailingWorking;
    }

    //create method inside class that interacts with the cars
    public void changePaintColor(Color newPaintColor){//signature of method
        this.paintColor = newPaintColor;//modify car object with new input
    }


//NOTES:
    //Argument: Actual value passed to the function
    //ex: (Red is the argument)
    //changePaintColor("Red");

    //Parameter: input variable & a method definition
    //ex:(color is the Parameter
    //public static void
    //changePaintColor(String color)
    //{...}

    //Method:
    //When a method is called,
    //the parameter(s) gets the value of the argument(s)
    //that were passed to the function.

//END NOTES:

    //** JAVA IS CALL BY VALUE ONLY

    //Call by value: passing argument into a function call
        //When a function receives a copy of the argument passed to it

    //function is unaffected by argument passed to function - call by value - does nothing
    public void speedingUp(double currentSpeed){

        currentSpeed += 100;
    }

    //Call by Reference: passing argument into a function call
        //When a function receives a reference to each argument, and can modify them - call by reference
    public double speedingUp2(double currentSpeed2){
        currentSpeed2 += 100;
            //return the value you want - returns the increased value
        return currentSpeed2;
    }


}
