import java.util.Random;

public class Dice {

    public final static int ONE = 1;
    public final static int TWO = 2;
    public final static int THREE = 3;
    public final static int FOUR = 4;
    public final static int FIVE = 5;
    public final static int SIX = 6;

    private int diceFace;
    int previousRoll = -1;

    public Dice(){
        roll();
    }

    public void roll(){
        Random rand = new Random();
        diceFace = rand.nextInt(6) + 1;
    }

    public String getDiceFace(){
        if (diceFace == ONE){
            return "[1]";
        }else if (diceFace == ONE){
            return "[1]";
        }else if (diceFace == TWO){
            return "[2]";
        }else if (diceFace == THREE){
            return "[3]";
        }else if (diceFace == FOUR){
            return "[4]";
        }else if (diceFace == FIVE){
            return "[5]";
        }else if (diceFace == SIX){
            return "[6]";
        }else {
            return "INVALID";
        }
    }
}
