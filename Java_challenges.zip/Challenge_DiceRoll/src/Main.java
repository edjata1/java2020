public class Main {

    public static void main(String[] args){

        Dice dice1 = new Dice();
        Dice dice2 = new Dice();

        for (int i = 0; i < 10; i++){

            dice1.roll();
            dice2.roll();

            int r;
            r = i + 1;

            System.out.println("Previous Roll Dice 1: " + dice1.previousRoll);
            System.out.println("Previous Roll Dice 2: " + dice2.previousRoll);

            System.out.println("Dice Roll " + r + ": "
                    + dice1.getDiceFace() + dice2.getDiceFace());

            System.out.println("Previous Roll Dice 1: " + dice1.previousRoll);
            System.out.println("Previous Roll Dice 2: " + dice2.previousRoll);
        }
    }
}
