package CH03.designpatterns.observer.weather;

public interface DisplayElement {
	public void display();
}
