package CH03.designpatterns.observer.weatherobservable;

public interface DisplayElement {
	public void display();
}
