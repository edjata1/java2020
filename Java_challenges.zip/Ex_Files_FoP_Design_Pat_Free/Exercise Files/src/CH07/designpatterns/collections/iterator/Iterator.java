package CH07.designpatterns.collections.iterator;

public interface Iterator {
	boolean hasNext();
	Object next();
}
