import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        //PROGRAMMING NOTE START: need to group so can't go to next without entering
        System.out.println("Enter name: ");
        String fName = sc.nextLine();

        System.out.println("Enter email: ");
        String userEmail = sc.nextLine();

        System.out.println("Enter phone number: ");
        String userNumber = sc.nextLine();

        //PROGRAMMING ISSUE: in "" PW matches, but not matching as variable from input sc, why??
//        System.out.println("Enter passworsd: ");
//        String userPWReg1 = sc.nextLine();
//
//        System.out.println("re-enter password: ");
//        String userPWReg2 = sc.nextLine();
        //PROGRAMMING NOTE END:

        UserRegistration newUser = new UserRegistration(fName, userEmail, userNumber, "5551", "5551");

        System.out.println("Hello " + fName + ", thank you for completing your registration!");

        //PW validation
        newUser.validatePassword(newUser.password, newUser.confirmmPassword);

        //phone formatting
        newUser.phoneNumberFormatted();

        //email validation check
        String email = newUser.email;
        if (UserRegistration.validateEmail(email))
            System.out.println("Thank you for registering with us!");
        else
            System.out.println("Sorry, that isn't a valid email!");


    }
}
