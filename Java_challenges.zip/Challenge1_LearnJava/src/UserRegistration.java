import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserRegistration {

    String userName;
    String email;
    String phoneNumber;
    String password;
    String confirmmPassword;

    public UserRegistration(String inputUserName,
                            String inputEmail,
                            String inputPhoneNumber,
                            String inputPassword,
                            String inputConfirmmPassword){

        this.userName = inputUserName;
        this.email = inputEmail;
        this.phoneNumber = inputPhoneNumber;
        this.password = inputPassword;
        this.confirmmPassword =inputConfirmmPassword;
    }

    public void validatePassword(String a, String b){

        if(this.password == this.confirmmPassword && !this.password.isEmpty() && !this.confirmmPassword.isEmpty()){
            System.out.println("Password Match Confirmed!");
        }else if(this.password != this.confirmmPassword && !this.password.isEmpty() && !this.confirmmPassword.isEmpty()){
            System.out.println("Password Match Not Confirmed!");
        }else if (this.password.isEmpty()){
            System.out.println("Please enter a password it's empty");
        }else if (this.confirmmPassword.isEmpty()){
            System.out.println("Please re-enter a password it's empty");
        }

    }

    public void phoneNumberFormatted (){
        String inputPN = this.phoneNumber;
        String phoneNum = inputPN.replaceFirst("(\\d{3})(\\d{3})(\\d+)","($1)$2-$3");
        System.out.println(phoneNum);
}

    public static boolean validateEmail(String email) {

       // validates_format_of :email, :with => /^(|(([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6})$/i;

        String emailRegex =
                "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null)
            return false;
        return pat.matcher(email).matches();
    }
}
