//import java.net.InetAddress;
//import java.net.UnknownHostException;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//import javax.servlet.http.HttpServletRequest;
//
//public class BrowserTypeHttpServletRequest {
//
//    public BrowserTypeHttpServletRequest{
//        private final static String IE11 = "rv:11.0";
//        private final static String IE10 = "MSIE 10.0";
//        private final static String IE9 = "MSIE 9.0";
//        private final static String IE8 = "MSIE 8.0";
//        private final static String IE7 = "MSIE 7.0";
//        private final static String IE6 = "MSIE 6.0";
//        private final static String FIREFOX = "Firefox";
//        private final static String OPERA = "Opera";
//        private final static String CHROME = "Chrome";
//        private final static String SAFARI = "Safari";
//        /* w w w . j  a  v  a  2s.  co  m*/
//        public static BrowserType getBrowserType(HttpServletRequest request) {
//            BrowserType browserType = null;
//            if (getBrowserType(request, IE11)) {
//                browserType = BrowserType.IE11;
//            }
//            if (getBrowserType(request, IE10)) {
//                browserType = BrowserType.IE10;
//            }
//            if (getBrowserType(request, IE9)) {
//                browserType = BrowserType.IE9;
//            }
//            if (getBrowserType(request, IE8)) {
//                browserType = BrowserType.IE8;
//            }
//            if (getBrowserType(request, IE7)) {
//                browserType = BrowserType.IE7;
//            }
//            if (getBrowserType(request, IE6)) {
//                browserType = BrowserType.IE6;
//            }
//            if (getBrowserType(request, FIREFOX)) {
//                browserType = BrowserType.Firefox;
//            }
//            if (getBrowserType(request, SAFARI)) {
//                browserType = BrowserType.Safari;
//            }
//            if (getBrowserType(request, CHROME)) {
//                browserType = BrowserType.Chrome;
//            }
//            if (getBrowserType(request, OPERA)) {
//                browserType = BrowserType.Opera;
//            }
//            if (getBrowserType(request, "Camino")) {
//                browserType = BrowserType.Camino;
//            }
//            return browserType;
//        }
//        private static boolean getBrowserType(HttpServletRequest request,
//                                              String brosertype) {
//            return request.getHeader("USER-AGENT").toLowerCase()
//                    .indexOf(brosertype) > 0 ? true : false;
//        }
//    }
//}
