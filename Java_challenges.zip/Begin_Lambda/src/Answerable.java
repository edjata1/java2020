public interface Answerable {
    String answer();
}
