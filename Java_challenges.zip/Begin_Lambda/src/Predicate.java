public interface Predicate {

        boolean test(Integer n);

}
