public class Main {

    public static void main(String[] args){
        BankAccount acct1 = new BankAccount(
                25615, 950);

        acct1.withdraw(750);
        acct1.deposit(65);
        acct1.withdraw(1000);
    }
}
