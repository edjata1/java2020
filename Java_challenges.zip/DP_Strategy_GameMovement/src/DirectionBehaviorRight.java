public class DirectionBehaviorRight implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player move Right x spaces");
    }
}
