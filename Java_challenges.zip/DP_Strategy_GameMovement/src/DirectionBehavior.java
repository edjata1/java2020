public interface DirectionBehavior {

    public void move();

}
