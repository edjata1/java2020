public class PlayerInactive implements Player {

    @Override
    public void player(String name) {
        System.out.println("Inactive Game Player");
    }
}
