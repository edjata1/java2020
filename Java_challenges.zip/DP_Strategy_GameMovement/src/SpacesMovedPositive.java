public class SpacesMovedPositive implements SpacesMoved {

    @Override
    public void spacesMoved() {
        System.out.println("Positive spaces moved");
    }
}
