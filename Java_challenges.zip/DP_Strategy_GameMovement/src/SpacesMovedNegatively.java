public class SpacesMovedNegatively implements SpacesMoved {

    @Override
    public void spacesMoved() {
        System.out.println("Negatively moved spaces");
    }
}
