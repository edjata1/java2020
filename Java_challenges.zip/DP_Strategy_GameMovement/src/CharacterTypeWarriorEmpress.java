public class CharacterTypeWarriorEmpress implements CharacterType {

    @Override
    public void characterType() {
        System.out.println("This is the Warrior Empress Character Type, selected!");
    }
}
