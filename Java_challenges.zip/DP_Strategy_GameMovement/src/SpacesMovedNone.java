public class SpacesMovedNone implements SpacesMoved {

    @Override
    public void spacesMoved() {
        System.out.println("No space were moved this time");
    }
}
