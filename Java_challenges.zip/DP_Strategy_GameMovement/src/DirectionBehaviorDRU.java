public class DirectionBehaviorDRU implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Diagonal Right Up x spaces");
    }
}
