public interface Player {

    public void player(String name);

}
