public interface CharacterType {

    public void characterType();
}
