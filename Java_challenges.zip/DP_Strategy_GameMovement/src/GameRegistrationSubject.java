public class GameRegistrationSubject {
}
