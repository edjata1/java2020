public class CharacterTypeWarrior implements CharacterType {

    @Override
    public void characterType() {
        System.out.println("This is the Warrior Character Type, selected!");
    }
}
