public class DirectionBehaviorDLD implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Diagonal Left Down x spaces");
    }
}
