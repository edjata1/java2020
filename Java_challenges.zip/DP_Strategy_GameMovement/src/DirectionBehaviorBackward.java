public class DirectionBehaviorBackward implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Backward x spaces");
    }
}
