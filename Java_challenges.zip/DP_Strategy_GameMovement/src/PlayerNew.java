public class PlayerNew implements Player {

    @Override
    public void player(String name) {
        System.out.println("Welcome to the game " + name);
    }
}
