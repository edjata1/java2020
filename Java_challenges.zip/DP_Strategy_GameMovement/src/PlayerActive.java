public class PlayerActive implements Player {

    @Override
    public void player(String name) {
        System.out.println("Active Game Player");
    }
}
