import java.util.Scanner;

public class GameSimulator {

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your player name: ");
        String newPlayerName = sc.nextLine();

        PlayerNew readyPlayer1 = new PlayerNew();

        readyPlayer1.player(newPlayerName);
        //System.out.println(newPlayerName);
    }
}
