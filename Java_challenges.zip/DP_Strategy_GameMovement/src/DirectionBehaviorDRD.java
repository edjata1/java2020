public class DirectionBehaviorDRD implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Diagonal Right Down x spaces");
    }
}
