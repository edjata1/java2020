public class CharacterTypeWizard implements CharacterType {

    @Override
    public void characterType() {
        System.out.println("This is the Wizard Character Type, selected!");
    }
}
