public class DirectionBehaviorForward implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Forward x spaces");
    }
}
