public interface SpacesMoved {

    public void spacesMoved();
}
