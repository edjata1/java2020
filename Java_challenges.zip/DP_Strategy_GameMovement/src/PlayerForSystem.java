public abstract class PlayerForSystem {

    public void playerForSystem(){

    }

    public void playerName(String name){
        System.out.println("Every player has a name. get name");
    }

    public void playerAccount(){
        System.out.println("Get player account information or register");
    }

    abstract void display();
}
