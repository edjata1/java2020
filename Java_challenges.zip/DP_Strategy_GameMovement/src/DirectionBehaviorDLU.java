public class DirectionBehaviorDLU implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Diagonal Left Up x spaces");
    }
}
