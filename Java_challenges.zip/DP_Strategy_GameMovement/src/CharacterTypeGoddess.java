public class CharacterTypeGoddess implements CharacterType {

    @Override
    public void characterType() {
        System.out.println("This is the Goddess Character Type, selected!");
    }

}
