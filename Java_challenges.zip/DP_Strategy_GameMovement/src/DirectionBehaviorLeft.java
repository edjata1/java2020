public class DirectionBehaviorLeft implements DirectionBehavior {

    @Override
    public void move() {
        System.out.println("Player moves Left x spaces");
    }
}
